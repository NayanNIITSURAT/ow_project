part of multi_image_selector;

class FileExt {
  FileExt(this.file, {this.filter});

  File file;
  Filter filter;
}

class ImageEditorView extends StatefulWidget {
  final List<FileExt> _selectedImages;
  final CropOptions _cropOptions;
  final List<Filter> filters;
  final EditorOptions _editorOptions;
  final Function(List<File>) onFinish;

  ImageEditorView(
    this._selectedImages, {
    cropOptions,
    this.filters,
    this.onFinish,
    editorOptions,
  })  : _cropOptions = cropOptions ?? const CropOptions(),
        _editorOptions = editorOptions ?? const EditorOptions();

  @override
  _ImageEditorViewState createState() => _ImageEditorViewState();
}

class _ImageEditorViewState extends State<ImageEditorView> {
  final Map<int, List<int>> _cachedMap = Map();
  List<FileExt> selectedImages = [];

  _ImageEditorViewState() {
    _loadPicker();
  }
  int _currentIndex = 0;
  final ImageFilterController _imageFilterController = ImageFilterController();

  @override
  void initState() {
    selectedImages = widget._selectedImages;

    // _imageFilterController.file = selectedImages[_currentIndex].file;
    _imageFilterController.filterChanged = (filter) {
      _onFilterEdited(filter);
    };

    super.initState();
  }

  @override
  void dispose() {
    _imageFilterController.dispose();
    super.dispose();
  }

  void _loadPicker({ImageSource source: ImageSource.gallery}) async {
    try {
      File pickedImage = await ImagePicker.pickImage(
        source: source,
        preferredCameraDevice: CameraDevice.rear,
      );

      var imageFile = await ImageCropper.cropImage(
        maxHeight: 500,
        maxWidth: 500,
        sourcePath: pickedImage.path,
        aspectRatio: CropAspectRatio(ratioX: 1.0, ratioY: 1.0),
      );

      if (imageFile != null) {
        selectedImages.add(FileExt(imageFile));
        // var curIndex =
        //     selectedImages.length < 2 ? 0 : selectedImages.length - 1;
        setState(() {
          // _imageFilterController.file = selectedImages[curIndex].file;
          // _currentIndex = curIndex;
        });
      }
    } catch (e) {
      print(e);
    }
  }

  Widget buildResultImage(FileExt asset) {
    Widget loader = const Center(child: CircularProgressIndicator());
    BoxFit fit = widget._cropOptions.fit;
    if (asset.file == null) {
      return Container();
    }
    if (asset.filter == null && asset.file != null) {
      return Image.file(asset.file, fit: fit);
    }

    // if (_cachedMap[idx] != null) {
    //   return Image.memory(_cachedMap[idx], fit: fit);
    // }

    return FutureBuilder<List<int>>(
      future: _decodeImageFromFile(asset.file).then((image) {
        return compute(applyFilter, <String, dynamic>{
          "filter": asset.filter,
          "image": image,
          "filename": basename(asset.file.path),
        });
        // ignore: invalid_return_type_for_catch_error
      }).catchError((e) => Future.error(e)),
      builder: (BuildContext context, AsyncSnapshot<List<int>> snapshot) {
        switch (snapshot.connectionState) {
          case ConnectionState.none:
          case ConnectionState.active:
          case ConnectionState.waiting:
            return loader;
          case ConnectionState.done:
            if (snapshot.hasError) return Image.file(asset.file, fit: fit);
            // _cachedMap[idx] = snapshot.data;
            return Image.memory(snapshot.data, fit: fit);
        }
        return null; // unreachable
      },
    );
  }

  Future<img.Image> _decodeImageFromFile(File file, {int resize}) async {
    try {
      img.Image image = img.decodeImage(await file.readAsBytes());
      return img.copyResize(image, width: resize ?? image.width);
    } catch (e) {
      return Future.error(e);
    }
  }

  void onFileEdited(File asset) {
    if (asset == null) {
      return;
    }

    _cachedMap[_currentIndex] = null;
    FileExt newFile = FileExt(asset);
    setState(() {
      selectedImages[_currentIndex] = newFile;
      _imageFilterController.file = newFile.file;
    });
  }

  void _onFilterEdited(Filter filter) {
    if (selectedImages[_currentIndex].filter != filter) {
      _cachedMap[_currentIndex] = null;
      selectedImages[_currentIndex].filter = filter;
    }
  }

  set currentIndex(int value) {
    print(value);
    if (_currentIndex != value)
      setState(() {
        _currentIndex = value;
        _imageFilterController.file = selectedImages[value].file;
      });
  }

  @override
  Widget build(BuildContext context) {
    final navPop = (List<FileExt> images) {
      var imageFiles = images.map((e) => e.file).toList();
      widget.onFinish(imageFiles);
      Navigator.of(context).pop();
    };
    return Scaffold(
      backgroundColor: widget._editorOptions.backgroundColor,
      appBar: AppBar(
        title: widget._editorOptions.title ?? null,
        centerTitle: widget._editorOptions.centerTitle,
        leading: IconButton(
          onPressed: () => navPop(widget._selectedImages),
          icon: Icon(
            Icons.chevron_left_sharp,
            size: 40,
          ),
        ),
        actions: <Widget>[
          IconButton(
            icon: widget._editorOptions.checkIcon,
            onPressed: () => navPop(selectedImages),
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.only(bottom: 32.0),
        child: Container(
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: <Widget>[
              GridView.builder(
                shrinkWrap: true,
                itemCount: selectedImages.length + 2,
                itemBuilder: (ctx, i) {
                  return i < 2
                      ? GestureDetector(
                          onTap: () => _loadPicker(
                              source: i == 0
                                  ? ImageSource.gallery
                                  : ImageSource.camera),
                          child: Container(
                            child: Icon(
                              i == 0 ? Icons.add : Icons.camera_alt_outlined,
                              color: Colors.grey[350],
                              size: 30,
                            ),
                            decoration: BoxDecoration(
                              border: Border.all(
                                color: Colors.grey[350],
                              ),
                              borderRadius: BorderRadius.circular(6),
                            ),
                          ),
                        )
                      : GridTile(
                          child: InkWell(
                          onTap: () => currentIndex = i - 2,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(6),
                            child: GridTile(
                              child: GestureDetector(
                                child: Image.file(
                                  selectedImages[i - 2].file,
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                        ));
                },
                padding: EdgeInsets.all(0),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 5,
                  childAspectRatio: 1.1,
                  crossAxisSpacing: 2,
                  mainAxisSpacing: 2,
                ),
              ),
              SizedBox(height: 15),
              Container(
                height: MediaQuery.of(context).size.width,
                child: Center(
                  child: Swiper.children(
                    // aspectRatio: 1 / 0.78,
                    loop: false,
                    children: selectedImages
                        .asMap()
                        .map(
                          (i, e) => MapEntry(
                            i,
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 8.0),
                              child: SliderItem(
                                imageItem:
                                    FileExt(_imageFilterController.value),
                                widget: widget,
                                onTap: _currentIndex == i ? onFileEdited : null,
                                child: buildResultImage(e),
                              ),
                            ),
                          ),
                        )
                        .values
                        .toList(),
                    // viewportFraction: 1.0,
                    autoplay: false,

                    viewportFraction: 0.8,
                    scale: 0.9,
                    onIndexChanged: (i) => setState(() {
                      currentIndex = i;
                    }),
                    index: _currentIndex,
                  ),
                ),
              ),
              // SizedBox(height: 15),
              // Container(
              //   constraints: BoxConstraints(
              //     maxHeight: widget._editorOptions.thumbnailSize +
              //         widget._editorOptions.marginBetween * 2 +
              //         40.0,
              //   ),
              //   child: ImageFilterSelector(
              //     controller: _imageFilterController,
              //     // filters: widget.filters,
              //     // editorOptions: widget._editorOptions,
              //   ),
              // ),
            ],
          ),
        ),
      ),
    );
  }
}

class SliderItem extends StatelessWidget {
  final Widget child;

  const SliderItem({
    Key key,
    @required this.imageItem,
    @required this.widget,
    this.onTap,
    @required this.child,
  }) : super(key: key);

  final FileExt imageItem;
  final ImageEditorView widget;
  final Function(File) onTap;

  Future<File> _cropImages(BuildContext context, String filePath) async {
    return ImageCropper.cropImage(
      sourcePath: filePath,
      maxWidth: widget._cropOptions.maxWidth,
      maxHeight: widget._cropOptions.maxHeight,
      aspectRatio: widget._cropOptions.aspectRatio,
      aspectRatioPresets: widget._cropOptions.aspectRatioPresets,
      compressFormat: widget._cropOptions.compressFormat,
      compressQuality: widget._cropOptions.compressQuality,
      androidUiSettings: widget._cropOptions.androidUiSettings,
      iosUiSettings: widget._cropOptions.iosUiSettings,
    );
  }

  @override
  Widget build(BuildContext context) {
    void _cropImage(FileExt imageAsset) async {
      if (imageAsset.file.path != null)
        onTap(await _cropImages(context, imageAsset.file.path));
    }

    return InkWell(
      onTap: () => _cropImage(imageItem),
      child: Stack(
        children: <Widget>[
          Container(
            width: double.infinity,
            height: double.infinity,
            child: Material(
              elevation: 4.0,
              child: child,
            ),
          ),
          Container(
            alignment: Alignment.bottomRight,
            child: IgnorePointer(
              child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: CircleAvatar(
                  backgroundColor: Colors.black54,
                  radius: 15,
                  child: Icon(
                    Icons.crop,
                    size: 13,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
